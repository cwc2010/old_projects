let blocktypes = {
  "Sand": {
    index: 1.52,
    color: "#C2B280",
    collisionrange: 0.2,
    isfluid: false
  },
  "Water": {
    index: 1,
    color: "#00F"
  },
  "Steam": {
    index: 0.000598,
    color: "#CCC",
    ygravityspeed: -0.5
  },
  "Water Bomb": {
    index: 7.85 /* metal */ + 10 /* water */,
    color: "#44F",
    collisionrange: 0,
    lifespan: 50,
    onremove: (i, lsrm) => {
      if (!lsrm) {
        return
      }
      for (let _ = 0; _ < 10; _++) {
        fallingblock(i.xloc, i.yloc, Math.random() * 50 - 25, Math.random() * -50, blocktypes["Water"], "Water")
      }
    }
  },
  "Smoke Grenade": {
    index: 7.85,
    color: "#999",
    collisionrange: 0,
    lifespan: 50,
    onremove: (i, lsrm) => {
      if (!lsrm) {
        return
      }
      for (let _ = 0; _ < 10; _++) {
        fallingblock(i.xloc, i.yloc, Math.random() * 50 - 25, Math.random() * 50, blocktypes["Steam"], "Steam")
      }
    }
  },
  "Mini Bomb": {
    index: 7.85 / 2,
    color: "#666",
    collisionrange: 0,
    lifespan: 150,
    onremove: (i, lsrm) => {
      if (!lsrm) {
        return
      }
      for (let _ = 0; _ < 5; _++) {
        fallingblock(i.xloc, i.yloc, Math.random() * 5 - 2.5, Math.random() * 5 - 2.5, blocktypes["Steam"], "Steam")
      }
      explosion(i.xloc, i.yloc, Math.random() * 5, Math.random() * 25)
    }
  },
  "Bomb": {
    index: 7.85,
    color: "#666",
    collisionrange: 0,
    lifespan: 150,
    onremove: (i, lsrm) => {
      if (!lsrm) {
        return
      }
      for (let _ = 0; _ < 50; _++) {
        fallingblock(i.xloc, i.yloc, Math.random() * 50 - 25, Math.random() * 50 - 25, blocktypes["Steam"], "Steam")
      }
      explosion(i.xloc, i.yloc, Math.random() * 25, Math.random() * 50)
    }
  },
  "Nuclear Bomb": {
    index: 7.85 * 3,
    color: "#333",
    collisionrange: 0,
    lifespan: 150,
    onremove: (i, lsrm) => {
      if (!lsrm) {
        return
      }
      explosion(i.xloc, i.yloc, Math.random() * 150, Math.random() * 100)
      for (let _ = 0; _ < 125; _++) {
        fallingblock(i.xloc, i.yloc, Math.random() * 50 - 25, Math.random() * 50 - 25, blocktypes["Steam"], "Steam")
      }
    }
  }
}










let mouse = {
  x: 0,
  y: 0,
  click: false
}

function mousemove(e) {
  e=e.touches?e.touches[0]:e
  mouse.x = Math.round(e.clientX / blocks.size - (blocks.size / 20))
  mouse.y = Math.round(e.clientY / blocks.size - (blocks.size / 20))
  mouse.movementX = mouse.x - mouse.prevX
  mouse.movementY = mouse.y - mouse.prevY
  mouse.prevX = mouse.x
  mouse.prevY = mouse.y
}
addEventListener("mousemove", mousemove)
addEventListener("touchmove", mousemove)
addEventListener("mousedown", () => {mouse.click = true})
addEventListener("touchstart", () => {mouse.click = true})
addEventListener("mouseup", () => {mouse.click = false})
addEventListener("touchend", () => {mouse.click = false})


/* ---Physics--- */



let O_updatespeed = 25
let canvas = document.getElementById("canvas")
let ctx = canvas.getContext("2d")
let graphics = 4
let pensize = 10
let pentype = "Block"
let pentypes = ["Block"]
pentypes = pentypes.concat(Object.keys(blocktypes))
pentypes.push("Eraser")

// Blocks

let blocks = {
  list: [],
  dim: {x: 200, y: 200},
  size: 3,
  init: function() {
    for (let x = 0; x < blocks.dim.x; x++) {
      blocks.list.push([])
      // Javascript automatically makes undefined keys, no error when accessed; no extra loop
    }
    // outer size
    canvas.style = `width: ${blocks.dim.x * blocks.size}px; height: ${blocks.dim.y * blocks.size}px;`
    // internal size
    canvas.width = blocks.dim.x * blocks.size * graphics
    canvas.height = blocks.dim.y * blocks.size * graphics
  },
  render: function() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    // Render all blocks
    for (let x = 0; x < blocks.list.length; x++) {
      let xlist = blocks.list[x]
      for (let y = 0; y < xlist.length; y++) {
        let block = xlist[y] 
        if (block != undefined) {
          ctx.fillStyle = block.color
          ctx.fillRect(x * blocks.size * graphics, y * blocks.size * graphics, blocks.size * graphics, blocks.size * graphics)
        }
      }
    }
    ctx.fillStyle = "#000"
    ctx.font = `${10 * graphics}px serif`;
    ctx.fillText(pentype + "(" + pensize + "x" + pensize + ")", 2.5 * graphics, 10 * graphics)
  },
  place: function(x, y, color = "#000000", index = 1) {
    try {
      blocks.list[Math.round(x)][Math.round(y)] = {color: color, index: index}
    } catch (e) {}
  },
  remove: function(x, y) {
    try {
      blocks.list[Math.round(x)][Math.round(y)] = undefined
    } catch (e) {}
  }
}
blocks.init()

function force(x, y, type, data) {
  forces[`${Math.round(x)},${Math.round(y)}`] = {type: type, data: data}
}
let data = []
function fallingblock(xloc, yloc, xv, yv, setoptions = {}, type) {
  let options = {
    color: "#00F",
    xgravityspeed: 0,
    ygravityspeed: 0.5,
    frictionmul: 0.9,
    collisionrange: 0.9,
    lifespan: Infinity,
    onremove: undefined,
    oncollision: undefined,
    index: 1,
    isfluid: true
  }
  
  Object.assign(options, setoptions)

  data.push({
    xloc: xloc,
    yloc: yloc,
    xv: xv,
    yv: yv,
    type: type,
    options: options
  })
}

let erased = {x: [], y: []}
let forces = {}
function renderobjects() {
  function collision(i, x, y) {
    x ??= i.xv
    y ??= i.yv
    let block = blocks.list?.[Math.round(i.xloc + x)]?.[Math.round(i.yloc + y)]
    if (block == undefined) {
      return 0
    } else if (block.index < i.options.index /* index override */) {
      return 2
    }
    return 1
  }

  let remove = []
  for (let i of data) {
    blocks.remove(i.xloc, i.yloc)
    i.options.lifespan--
    // Is in bounds
    if (i.xloc > blocks.dim.x || i.xloc <= 0 || i.yloc > blocks.dim.y || i.options.lifespan <= 0 || (erased.x.includes(Math.round(i.xloc)) && erased.y.includes(Math.round(i.yloc)))) {
      if (i.options.onremove) {
        i.options.onremove(i, i.options.lifespan <= 0)
      }
      remove.push(i)
      continue
    }
    // Add gravity
    i.xv += i.options.xgravityspeed
    i.yv += i.options.ygravityspeed
    // Add friction
    i.xv *= i.options.frictionmul
    i.yv *= i.options.frictionmul
    // Splash
    let collisionstate = collision(i)
    if (i.options.oncollision) {
      i.options.oncollision(i, collisionstate, blocks.list?.[Math.round(i.xloc + i.xloc)]?.[Math.round(i.yloc + i.yloc)])
    }
    if (collisionstate == 1) {
      let collrange = i.options.collisionrange
      let mul1 = Math.random() * ((collrange * 2)) - collrange,
        mul2 = Math.random() * ((collrange * 2)) - collrange
      let xv = i.yv * mul1
      i.yv = i.xv * mul2
      i.xv = xv
      if (i.options.isfluid) {
        let free_r = !collision(i, 1, 0)
        let free_l = !collision(i, -1, 0)
        if (free_r && free_l) {
          i.xv += Math.random() * (Math.random() < 0.5 ? 1 : -1)
        } else if (free_r) {
          i.xv += Math.random()
        } else if (free_l) {
          i.xv += Math.random() * -1
        }
      }
    } else if (collisionstate == 2) {
      let toX = Math.round(i.xloc + i.xv)
      let toY = Math.round(i.yloc + i.yv)
      for (let x = 0; x < data.length; x++) {
        let block = data[x]
        if (Math.round(block.xloc) == toX && Math.round(block.yloc) == toY) {
          block.xloc = i.xloc
          block.yloc = i.yloc
          data[x] = block
        }
      }
      i.xloc += i.xv
      i.yloc += i.yv
      // Need to switch blocks, should have used different approach at start :(
    } else {
    // Keep moving
      i.xloc += i.xv
      i.yloc += i.yv
    }
    // Render this block
    blocks.place(i.xloc, i.yloc, i.options.color, i.options.index)
  }
  data = data.filter(i => !remove.includes(i))
  
  erased = {x: [],y: []}
  forces = {}
  blocks.render()
}


function place() {
  if (!mouse.click) {
    return
  }
  for (let x = 0; x < pensize; x++) {
    for (let y = 0; y < pensize; y++) {
      let loc = [Math.round(mouse.x + x - (pensize / 2)), Math.round(mouse.y + y - (pensize / 2))]
      switch (pentype) {
        case "Block": 
          blocks.place(...loc, "#000", 99999)
          break
        case "Eraser":
          blocks.remove(...loc)
          erased.x.push(loc[0])
          erased.y.push(loc[1])
          break
        default:
          fallingblock(...loc, (mouse.movementX * 2) ?? 0, (mouse.movementY * 2) ?? 0, blocktypes[pentype], pentype)
          break
      }
    }
  }
}


function explosion(x, y, radius, power) {
  for (let i = 0; i < data.length; i++) {
    let block = data[i]
    let distance = Math.sqrt(((block.xloc - x) ** 2) + ((block.yloc - y) ** 2))
    if (distance <= radius) {
      block.xv += Math.random() * (power * 2) - power
      block.yv += Math.random() * (power * 2) - power
    }
    data[i] = block
  }
  for (let xloc = 0; xloc < blocks.list.length; xloc++) { 
    for (let yloc = 0; yloc < blocks.list.length; yloc++) {
      let distance = Math.sqrt(((xloc - x) ** 2) + ((yloc - y) ** 2))
      if (distance <= radius && distance / radius < Math.random() * (power / 100)) {
        blocks.remove(xloc, yloc)
      }
    }
  }
}


addEventListener("mousemove", place)
addEventListener("touchmove", place)
addEventListener("mousedown", place)
addEventListener("touchstart", place)
setInterval(renderobjects, O_updatespeed)
setInterval(blocks.render)


/* ---GUI--- */

let area = document.createElement("div")
area.style = `
border: 1px solid #000;
position: absolute;
top: ${canvas.style.height};
left: 0;
width: ${canvas.style.width};
`
document.body.appendChild(area)

function button(text, fn, append = area) {
  let btn = document.createElement("button")
  btn.style = "margin: 10px; padding: 10px;"
  btn.innerText = text
  btn.addEventListener("click", fn)
  append.appendChild(btn)
  return btn
}
function input(type, fn, default_val, append = area) {
  let input = document.createElement("input")
  input.type = type
  input.style = "margin: 10px"
  if (default_val != undefined) {
    input.value = default_val
  }
  input.addEventListener("input", fn)
  append.appendChild(input)
  return input
}
function text(val, append = area) {
  let txt = document.createElement("pre")
  txt.style.display = "inline"
  txt.innerText = val
  append.appendChild(txt)
  return txt
}
function setpen(x) {
  return function () {
    pentype = x
  }
}
button("Block", setpen("Block"))
button("Eraser", setpen("Eraser"))
let pensize_inp = input("number", (e) => {pensize = +e.target.value}, 10, text("Pen size: "))
pensize_inp.min = 0
pensize_inp.max = 99
for (let i in blocktypes) {
  if (!blocktypes[i].guihidden) {
    button(blocktypes[i].guiname || i, setpen(i))
  }
}


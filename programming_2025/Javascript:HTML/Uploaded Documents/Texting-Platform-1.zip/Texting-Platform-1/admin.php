<title>Admin Page</title>
<form action="adminsend.php" method="post">
  Name: <input name="name" value="Admin"><br>
  User: <input name="user"><br>
  Password: <input name="pwd" type="password"><br>
  HTML Message: &lt;p style="color:red;font-weight:bold"&gt;<input name="html">&lt;p&gt;<br>
  Action: <input name="script"><br>
  <button>Execute</button>
</form>
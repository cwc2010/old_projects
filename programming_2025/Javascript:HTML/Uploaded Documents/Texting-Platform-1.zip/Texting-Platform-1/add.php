<?php
foreach(json_decode(file_get_contents("banlist.json")) as $banned){
  if(gethostname()==$banned){
    echo "<title>Banned</title><h1 style=text-align:center;color:#F00;font-size:100px>Error<br><sub style=font-size:50px;font-style:italic;color:#D00>You were banned</sub></h1>";
    die;
  }
} 
if((!array_key_exists("text",$_POST))||(!array_key_exists("name",$_POST))||$_POST["text"]==""||str_replace(" ","",$_POST["name"])==""){
  header("Location: /");
  die;
}
if($_POST["name"]=="Admin"){
  include "admin.php";
  die;
}
header("Location: /");
file_put_contents('log.txt', htmlspecialchars($_POST["name"]).": ". htmlspecialchars($_POST["text"])."<br>".file_get_contents("log.txt"));
file_put_contents('hostnamelog.txt', htmlspecialchars($_POST["name"])."(".gethostname()."): ". htmlspecialchars($_POST["text"])."<br>".file_get_contents("hostnamelog.txt"));
?>
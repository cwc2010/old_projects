<?php
  if((!array_key_exists("user",$_POST))||(!array_key_exists("pwd",$_POST))||(!array_key_exists("html",$_POST))||(!array_key_exists("script",$_POST))){
    die;
  }
  foreach ((json_decode(file_get_contents("admins.json"),1)) as $usrpwd){
    if(hash("sha256","0cf4391a-9a39-4a0f-908f-3fb8b42e861a".$_POST["user"])==$usrpwd[0]&&hash("sha256","0cf4391a-9a39-4a0f-908f-3fb8b42e861a".$_POST["pwd"])==$usrpwd[1]){
      // s - script;* - all
      if($_POST["html"]!=""&&(str_contains("m",$usrpwd[2])||str_contains("*",$usrpwd[2]))){
        file_put_contents('log.txt', "<span style='color:red;font-weight:bold'>".$_POST["name"].": ".$_POST["html"]."</span><br>".file_get_contents("log.txt"));
        file_put_contents('hostnamelog.txt', "<span style='color:red;font-weight:bold'>".$_POST["name"]."(".gethostname()."): ".$_POST["html"]."</span><br>".file_get_contents("hostnamelog.txt"));
      }
      // Script permissions
      if(str_contains("s",$usrpwd[2])||str_contains("*",$usrpwd[2])){
        echo shell_exec($_POST["script"]);
        file_put_contents('hostnamelog.txt', "<pre>SCRIPT: ".$_POST["script"]."</pre><br>".file_get_contents("hostnamelog.txt"));
      }else if($_POST["script"]!=""){
        echo "You do not have permissions to execute actions.";
      }
      echo "<title>Message Sent</title>";
      die;
    }
  }
  echo "<title>Permission Denined</title>Incorrect password/username";
?>
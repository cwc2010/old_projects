import json
import sys
banlist=json.loads(open("banlist.json","r").read())
banlist.append(sys.argv[1])
open("banlist.json","w").write(json.dumps(banlist))
<title>Texting Platform</title>
<h1>Texting Platform</h1>
<form method="post" action="add.php">
  Your name: <input name="name" value="Anonymous"><br>
  Text: <input name="text"><button>Send</button>
</form>
<pre id="log"></pre>
<script>
  if(localStorage.name!=undefined){
    document.querySelector("[name=name]").value=localStorage.name
  }
  document.querySelector("[name=name]").addEventListener("change",e=>{
    localStorage.name=e.target.value
  })
  document.querySelector("[name=text]").focus()
  async function update(){
document.getElementById("log").innerHTML=await (await fetch("log.txt")).text()
  }
  update()
  setInterval(e=>{
    update()
  }, 5000 /* delay for texts, make this number higher if this project becomes popular */)
</script>
<?php
  include("start.php")
?>